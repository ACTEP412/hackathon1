import json
import base64
import hmac
from cryptography.fernet import Fernet
from Crypto.PublicKey import ECC
from Crypto.Hash import SHA256
from socketserver import ThreadingTCPServer, BaseRequestHandler

messages = {}
clients = {}

class DiffieHellman:
    def __init__(self):
        self.private_key = ECC.generate(curve='P-256')
        self.public_key = self.private_key.public_key()

    def get_public_key(self):
        return self.public_key.export_key(format='DER')

    def generate_shared_key(self, peer_public_key):
        peer_key = ECC.import_key(peer_public_key)
        shared_secret = self.private_key.d * peer_key.pointQ
        shared_key = SHA256.new(shared_secret.x.to_bytes(32, byteorder='big')).digest()
        return shared_key

dh_server = DiffieHellman()

def process_request(data):
    try:
        try:
            data = json.loads(data)
        except json.JSONDecodeError:
            return {"error": "Invalid JSON format"}

        command = data.get('command')

        if command == 'register_client':
            client_id = data['client_id']
            client_public_key = base64.b64decode(data['public_key'])
            shared_key = dh_server.generate_shared_key(client_public_key)

            # Создание Fernet Key
            fernet_key = base64.urlsafe_b64encode(shared_key[:32])
            clients[client_id] = fernet_key  # Сохраняем Fernet Key для клиента

            return {
                "server_public_key": base64.b64encode(dh_server.get_public_key()).decode()
            }


        elif command == 'send_message':
            sender_id = data['sender_id']
            recipient_id = data['recipient_id']
            message = data['message']
            hmac_digest = data['hmac']

            key = clients.get(sender_id)
            if not key:
                return {"error": "Unknown sender"}

            fernet = Fernet(key)
            decrypted_message = fernet.decrypt(message.encode()).decode()
            calculated_hmac = hmac.new(key, message.encode(), digestmod='sha256').digest()

            if not hmac.compare_digest(calculated_hmac, base64.b64decode(hmac_digest)):
                return {"error": "HMAC verification failed"}

            messages[recipient_id] = messages.get(recipient_id, []) + [{"from": sender_id, "message": decrypted_message}]

            messages[sender_id] = messages.get(sender_id, []) + [{"from": sender_id, "message": decrypted_message}]

            log_message = f"{sender_id} — {recipient_id}: {decrypted_message}"
            print(log_message)

            return {
                "status": "Message sent",
                "formatted_message": log_message
            }

        elif command == 'retrieve_messages':
            client_id = data['client_id']
            user_messages = messages.pop(client_id, [])
            return {"messages": user_messages}
        
        else:
            return {"error": "Unknown command"}

    except Exception as e:
        return {"error": str(e)}

class ServerHandler(BaseRequestHandler):
    def handle(self):
        try:
            data = self.request.recv(4096).strip()
            try:
                decoded_data = data.decode()
            except UnicodeDecodeError:
                self.request.sendall(json.dumps({"error": "Invalid data encoding"}).encode())
                return
            
            response = process_request(decoded_data)
        except Exception as e:
            response = {"error": f"Server error: {str(e)}"}
        
        self.request.sendall(json.dumps(response).encode())

if __name__ == "__main__":
    with ThreadingTCPServer(("0.0.0.0", 5000), ServerHandler) as server:
        print("Server running on port 5000...")
        server.serve_forever()
