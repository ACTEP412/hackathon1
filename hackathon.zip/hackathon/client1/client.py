import base64
import hmac
import json
import socket
import os
from cryptography.fernet import Fernet
from Crypto.PublicKey import ECC
from Crypto.Hash import SHA256

SERVER_ADDRESS = ("127.0.0.1", 5000)

class DiffieHellman:
    def __init__(self):
        self.private_key = ECC.generate(curve='P-256')
        self.public_key = self.private_key.public_key()

    def get_public_key(self):
        return self.public_key.export_key(format='DER')

    def generate_shared_key(self, peer_public_key):
        peer_key = ECC.import_key(peer_public_key)
        shared_secret = self.private_key.d * peer_key.pointQ
        shared_key = SHA256.new(shared_secret.x.to_bytes(32, byteorder='big')).digest()
        return shared_key

def send_request(data):
    with socket.create_connection(SERVER_ADDRESS) as sock:
        sock.sendall(json.dumps(data).encode())
        response = sock.recv(4096)
        return json.loads(response.decode())

def register_client(client_id):
    dh_client = DiffieHellman()
    dh_client_public = dh_client.get_public_key()

    response = send_request({
        "command": "register_client",
        "client_id": client_id,
        "public_key": base64.b64encode(dh_client_public).decode()
    })

    server_public_key = base64.b64decode(response['server_public_key'])
    shared_key = dh_client.generate_shared_key(server_public_key)
    return base64.urlsafe_b64encode(shared_key[:32])

def send_message(client_id, fernet_key, recipient_id, message):
    fernet = Fernet(fernet_key)
    encrypted_message = fernet.encrypt(message.encode())
    hmac_digest = hmac.new(fernet_key, encrypted_message, digestmod='sha256').digest()

    response = send_request({
        "command": "send_message",
        "sender_id": client_id,
        "recipient_id": recipient_id,
        "message": encrypted_message.decode(),
        "hmac": base64.b64encode(hmac_digest).decode()
    })
    
    if response.get("status") == "Message sent":
        print(response["formatted_message"])
    else:
        print(f"Ошибка: {response.get('error')}")

def retrieve_messages(client_id):
    response = send_request({"command": "retrieve_messages", "client_id": client_id})
    print("Полученные сообщения:")
    for msg in response.get('messages', []):
        print(f"От {msg['from']}: {msg['message']}")

if __name__ == "__main__":
    client_id = input("Введите ваш ID клиента: ")
    key = register_client(client_id)
    print(f"Клиент {client_id} успешно зарегистрирован.")

    while True:
        action = input("Выберите действие:\n1 - отправить сообщение\n2 - получить сообщения\n"
                       "3 - выход...\n").strip()
        if action == "1":
            recipient = input("Введите ID получателя: ")
            msg = input("Введите сообщение: ")
            send_message(client_id, key, recipient, msg)
        elif action == "2":
            retrieve_messages(client_id)
        elif action == "3":
            break
        else:
            print("Неверный ввод.")